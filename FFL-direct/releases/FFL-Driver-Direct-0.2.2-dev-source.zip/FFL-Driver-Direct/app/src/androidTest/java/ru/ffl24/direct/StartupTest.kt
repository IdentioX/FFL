package ru.ffl24.direct

import androidx.activity.compose.setContent
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsOn
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.state.ToggleableState
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.semantics.SemanticsActions
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import androidx.test.platform.app.InstrumentationRegistry
import ru.ffl24.direct.data.mysql.DirectMySqlSettings
import ru.ffl24.direct.ui.DirectApp

class StartupTest {
    @get:Rule
    val compose = createAndroidComposeRule<MainActivity>()

    @Test
    fun coldStartAndNavigationHaveNoConnectionInput() {
        compose.onNodeWithTag("configuration_missing").assertIsDisplayed()
        compose.onNodeWithText("Подключение не настроено").assertIsDisplayed()
        assertNoEditableFields()
        compose.onNodeWithText("Адрес API").assertDoesNotExist()
        compose.onNodeWithText("Адрес сервера").assertDoesNotExist()
        compose.onNodeWithTag("open_settings").performClick()
        compose.onNodeWithText("Тёмная тема").assertIsDisplayed()
        assertNoEditableFields()
        turnDarkOn()
        compose.onNodeWithTag("back").performClick()
        compose.onNodeWithTag("configuration_missing").assertIsDisplayed()
    }

    @Test
    fun recreationPreservesNavigationAndThemeWithoutSetupFlow() {
        compose.onNodeWithTag("open_settings").performClick()
        turnDarkOn()
        compose.activityRule.scenario.recreate()
        compose.onNodeWithText("Тёмная тема").assertIsDisplayed()
        compose.onNodeWithTag("dark_theme").assertIsOn()
        assertNoEditableFields()
    }

    @Test
    fun refusedConnectionShowsSafeMessageAndRetryWithoutCredentials() {
        val ca = InstrumentationRegistry.getInstrumentation().context.assets.open("fixture-ca.pem").bufferedReader().use { it.readText() }
        val graph = AppGraph.create("DIRECT_MYSQL", DirectMySqlSettings(
            "127.0.0.1", "1", "fixture", "fixture_read", "fixture-only", "true", ca
        ))
        compose.activityRule.scenario.onActivity { it.setContent { DirectApp(graph) } }
        compose.waitUntil(30_000) { compose.onAllNodesWithTag("connection_failed").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("connection_failed").assertIsDisplayed()
        compose.onNodeWithText("fixture_read", substring = true).assertDoesNotExist()
        compose.onNodeWithText("127.0.0.1", substring = true).assertDoesNotExist()
        assertNoEditableFields()
        compose.onNodeWithTag("retry_connection").performClick()
        compose.waitUntil(30_000) { compose.onAllNodesWithTag("connection_failed").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("open_settings").performClick()
        assertNoEditableFields()
    }

    @Test
    fun incompleteConfigHasNoSetupInputs() {
        val graph = AppGraph.create("DIRECT_MYSQL", DirectMySqlSettings(host = "localhost"))
        compose.activityRule.scenario.onActivity { it.setContent { DirectApp(graph) } }
        compose.onNodeWithTag("configuration_invalid").assertIsDisplayed()
        assertNoEditableFields()
    }

    private fun turnDarkOn() {
        val node = compose.onNodeWithTag("dark_theme")
        if (node.fetchSemanticsNode().config[SemanticsProperties.ToggleableState] != ToggleableState.On) node.performClick()
        node.assertIsOn()
    }

    private fun assertNoEditableFields() {
        val nodes = compose.onAllNodes(SemanticsMatcher.keyIsDefined(SemanticsActions.SetText)).fetchSemanticsNodes()
        val date = compose.onAllNodesWithTag("work_date").fetchSemanticsNodes()
        assertEquals(date.size, nodes.size)
        compose.onNodeWithText("Адрес API").assertDoesNotExist()
        compose.onNodeWithText("Адрес сервера").assertDoesNotExist()
    }
}
