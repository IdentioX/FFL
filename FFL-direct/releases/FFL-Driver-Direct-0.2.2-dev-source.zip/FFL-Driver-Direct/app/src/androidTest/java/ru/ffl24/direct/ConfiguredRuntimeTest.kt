package ru.ffl24.direct

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import ru.ffl24.direct.domain.*

/** Ordinary MainActivity/DirectApplication/BuildConfig; no injected graph. */
class ConfiguredRuntimeTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()

    private fun choose(db: OwnedTestDatabase) {
        compose.waitUntil(60_000) { compose.onAllNodesWithTag("driver_search").fetchSemanticsNodes().isNotEmpty() }
        if (db.restored) compose.onNodeWithTag("driver_search").performTextInput("FFL E2E")
        compose.waitUntil(30_000) { compose.onAllNodesWithTag("driver_${db.driver}").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("driver_${db.disabled}").assertDoesNotExist()
        compose.onNodeWithTag("driver_${db.driver}").performClick()
    }

    @Test fun freshLoginOrdersDetailsDeliveryAndDirectoryUseCompiledConfiguration() {
        val db = OwnedTestDatabase()
        choose(db)
        compose.onNodeWithTag("configuration_missing").assertDoesNotExist()
        compose.onNodeWithTag("login").performClick()
        compose.onNodeWithTag("driver_password").performTextInput("wrong-fixture-password")
        compose.onNodeWithTag("confirm_login").performClick()
        compose.waitUntil(45_000) { compose.onAllNodesWithTag("invalid_credentials").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("login").performClick()
        compose.onNodeWithTag("driver_password").performTextInput(db.password)
        compose.onNodeWithTag("confirm_login").performClick()
        compose.waitUntil(45_000) { compose.onAllNodesWithTag("orders").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("open_settings").performClick()
        compose.onNodeWithTag("work_date").performTextReplacement(db.date)
        compose.onNodeWithText("Применить дату").performClick()
        compose.onNodeWithTag("back").performClick()
        compose.waitUntil(45_000) { compose.onAllNodesWithTag("order_reys:${db.order}").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("section_1").performClick()
        compose.onNodeWithTag("order_reys_den:${db.order}").assertIsDisplayed()
        compose.onNodeWithTag("section_2").performClick()
        compose.onNodeWithTag("order_reys:${db.order + 1}").assertIsDisplayed()
        compose.onNodeWithTag("section_0").performClick()
        compose.onNodeWithTag("order_reys:${db.order}").performClick()
        compose.waitUntil(45_000) { compose.onAllNodesWithText(db.address).fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Сдал").performClick()
        compose.onNodeWithTag("confirm_delivery").performClick()
        compose.waitUntil(45_000) { compose.onAllNodesWithText("Заказ сдан").fetchSemanticsNodes().isNotEmpty() }
        val graph = (compose.activity.application as DirectApplication).graph
        runBlocking {
            val details = (graph.orderDetailsRepository.getDetails(OrderId(OrderSource.REYS, db.order)) as DetailsResult.Success).value
            assertTrue(details.isDelivered); assertNotNull(details.deliveredAt)
        }
        compose.onNodeWithTag("back").performClick()
        compose.onNodeWithTag("section_2").performClick()
        compose.waitUntil(45_000) { compose.onAllNodesWithTag("order_reys:${db.order}").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Телефоны").performClick()
        compose.waitUntil(45_000) { compose.onAllNodesWithTag("phone_directory").fetchSemanticsNodes().isNotEmpty() }
        if (!db.restored) compose.onNodeWithText("Fixture holder").assertIsDisplayed()
        compose.onNodeWithTag("back").performClick()
    }

    @Test fun coldProcessRestoresPersistedSessionAndDateThenLogsOut() {
        val db = OwnedTestDatabase()
        compose.waitUntil(60_000) { compose.onAllNodesWithTag("orders").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("driver_${db.driver}").assertDoesNotExist()
        compose.onNodeWithText(db.date).assertIsDisplayed()
        compose.onNodeWithTag("section_2").performClick()
        compose.waitUntil(45_000) { compose.onAllNodesWithTag("order_reys:${db.order}").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("open_settings").performClick()
        compose.onNodeWithText("Выйти из аккаунта").performScrollTo().performClick()
        compose.waitUntil(45_000) { compose.onAllNodesWithTag("driver_list").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("orders").assertDoesNotExist()
        runBlocking { assertNull((compose.activity.application as DirectApplication).graph.sessions.current().session) }
    }
}
