package ru.ffl24.direct

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.SystemClock
import android.view.accessibility.AccessibilityNodeInfo
import androidx.work.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import ru.ffl24.direct.data.mysql.*
import ru.ffl24.direct.domain.AuthResult
import ru.ffl24.direct.local.WorkspacePreferences
import ru.ffl24.direct.notifications.*

/** A real PendingIntent owns its activity/task; ActivityScenario must not own that handoff. */
class ConfiguredNotificationTest {
    @Test fun realWorkManagerPollsMysqlDeduplicatesAndOpensSecondRoute() {
        val db = OwnedTestDatabase()
        val context = db.context
        val graph = (context.applicationContext as DirectApplication).graph
        val local = WorkspacePreferences(context)
        runBlocking {
            assertTrue(graph.authRepository.login(db.driver, db.password.toCharArray()) is AuthResult.Success)
            local.setDate(db.date); local.clearSeen(); local.setNotifications(false)
        }
        val manager = WorkManager.getInstance(context)
        val notifications = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        SecondRouteNotifications.cancel(context)
        context.startActivity(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        fun waitFor(timeout: Long = 60_000, condition: () -> Boolean) {
            val deadline = SystemClock.elapsedRealtime() + timeout
            while (!condition() && SystemClock.elapsedRealtime() < deadline) SystemClock.sleep(150)
            assertTrue("Timed out waiting for an owned local runtime condition", condition())
        }
        fun texts(node: AccessibilityNodeInfo?): String {
            if (node == null) return ""
            val result = buildString {
                append(node.text ?: ""); append('\n')
                for (i in 0 until node.childCount) append(texts(node.getChild(i)))
            }
            @Suppress("DEPRECATION") node.recycle()
            return result
        }
        fun visibleText() = texts(db.instrumentation.uiAutomation.rootInActiveWindow)
        waitFor { visibleText().contains(if (db.restored) "FFL E2E Driver" else "Fixture driver") }
        // Exercise the actual worker once at a time, independently of 15-minute scheduling.
        runBlocking { local.setNotifications(true) }
        fun poll() {
            val work = OneTimeWorkRequestBuilder<SecondRouteWorker>().setInputData(workDataOf("driver" to db.driver)).build()
            manager.enqueue(work).result.get(30, java.util.concurrent.TimeUnit.SECONDS)
            waitFor { manager.getWorkInfoById(work.id).get()?.state?.isFinished == true }
            assertEquals(WorkInfo.State.SUCCEEDED, manager.getWorkInfoById(work.id).get()?.state)
        }
        try {
            poll()
            waitFor(10_000) { notifications.activeNotifications.isEmpty() }
            val scope = "${db.driver}:${db.date}"
            assertTrue(runBlocking { local.seen(scope) } == setOf("reys_den:${db.order}"))
            MySqlConnectionFactory().open(db.jdbc, ConnectionPolicy()).use { connection ->
                connection.isReadOnly = false
                connection.prepareStatement("UPDATE reys_den SET st_vv=0,date_att_log=NULL WHERE id=? AND id_v=?").use {
                    it.setLong(1, db.notification); it.setLong(2, db.driver); assertEquals(1, it.executeUpdate())
                }
            }
            poll()
            waitFor(10_000) { notifications.activeNotifications.size == 1 }
            val posted = notifications.activeNotifications.single()
            assertEquals("Новые заказы второго рейса", posted.notification.extras.getString(android.app.Notification.EXTRA_TITLE))
            assertTrue(posted.notification.extras.getString(android.app.Notification.EXTRA_TEXT).orEmpty().startsWith("Новых заказов: 1."))
            assertTrue(runBlocking { local.seen(scope) } == setOf("reys_den:${db.order}", "reys_den:${db.notification}"))
            poll()
            assertEquals(posted.postTime, notifications.activeNotifications.single().postTime)
            posted.notification.contentIntent.send()
            waitFor { visibleText().contains("● Второй рейс") }
            waitFor { visibleText().contains(if (db.restored) "FFL-E2E-NOTIFICATION" else "Notification-fixture") }
            if (db.restored) {
                val directory = java.io.File(context.filesDir, "restored-private").apply { mkdirs() }
                java.io.File(directory, "controlled-second-route.png").outputStream().use {
                    db.instrumentation.uiAutomation.takeScreenshot().compress(Bitmap.CompressFormat.PNG, 100, it)
                }
            }
        } finally {
            runBlocking { local.setNotifications(false) }
            SecondRouteNotifications.cancel(context)
        }
    }
}
