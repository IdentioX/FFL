package ru.ffl24.direct.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import java.time.LocalDate

@Composable
fun WorkspaceSettings(dark: Boolean, theme: (Boolean)->Unit, date: String, changeDate: (String?)->Unit,
    notifications: Boolean, notify: (Boolean)->Unit, logout: ()->Unit, signedIn: Boolean) {
    var input by remember(date) { mutableStateOf(date) }
    val valid=runCatching { LocalDate.parse(input).toString()==input }.getOrDefault(false)
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(24.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Row { Text("Тёмная тема",Modifier.weight(1f)); Switch(dark,theme,Modifier.testTag("dark_theme")) }
        Text("Рабочая дата",style=MaterialTheme.typography.titleMedium)
        OutlinedTextField(input,{ input=it },label={ Text("ГГГГ-ММ-ДД") },singleLine=true,isError=!valid,modifier=Modifier.testTag("work_date"))
        Row {
            TextButton(onClick={ changeDate(input) },enabled=valid) { Text("Применить дату") }
            TextButton(onClick={ changeDate(null) }) { Text("Сегодня") }
        }
        Text("По умолчанию используется сегодняшняя дата телефона. Применённая вручную дата сохраняется.")
        Row { Text("Уведомления второго рейса",Modifier.weight(1f)); Switch(notifications,notify) }
        Text("Фоновая проверка примерно раз в 15 минут при наличии сети. Android может задерживать её в режиме экономии энергии. Первый успешный запрос запоминает текущие заказы без уведомления.")
        if(signedIn) TextButton(onClick=logout) { Text("Выйти из аккаунта") }
    }
}
