package ru.ffl24.direct.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import ru.ffl24.direct.R
import ru.ffl24.direct.domain.AuthError
import ru.ffl24.direct.presentation.AuthUiState
import ru.ffl24.direct.presentation.SetupAuthViewModel

@Composable
fun AuthScreen(state: AuthUiState, model: SetupAuthViewModel) {
    when (state) {
        AuthUiState.Loading -> Column(
            Modifier.fillMaxSize().padding(24.dp).testTag("connection_checking"),
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CircularProgressIndicator()
            Text(stringResource(R.string.auth_loading), Modifier.padding(top = 16.dp))
        }
        is AuthUiState.Choosing -> DriverChooser(state, model)
        is AuthUiState.Authenticated -> Column(
            Modifier.fillMaxSize().padding(24.dp).testTag("authenticated"),
            verticalArrangement = Arrangement.Center
        ) {
            Text(stringResource(R.string.signed_in), style = MaterialTheme.typography.titleLarge)
            Text(state.session.displayName, Modifier.padding(vertical = 16.dp))
            Button(onClick = model::recheckAccess, modifier = Modifier.testTag("check_access")) {
                Text(stringResource(R.string.check_access))
            }
            TextButton(onClick = model::logout, modifier = Modifier.testTag("logout")) {
                Text(stringResource(R.string.logout))
            }
        }
        AuthUiState.Disabled -> Column(
            Modifier.fillMaxSize().padding(24.dp).testTag("driver_disabled"),
            verticalArrangement = Arrangement.Center
        ) {
            Text(stringResource(R.string.driver_disabled), style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.driver_disabled_body), Modifier.padding(vertical = 16.dp))
            Button(onClick = model::retry) { Text(stringResource(R.string.refresh_drivers)) }
            TextButton(onClick = model::logout) { Text(stringResource(R.string.choose_another_driver)) }
        }
        is AuthUiState.Failed -> Column(
            Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center
        ) {
            Text(stringResource(errorMessage(state.error)), Modifier.testTag("connection_failed"))
            Button(onClick = model::retry, modifier = Modifier.testTag("retry_connection")) {
                Text(stringResource(R.string.retry_connection))
            }
            TextButton(onClick = model::logout) { Text(stringResource(R.string.choose_another_driver)) }
        }
        AuthUiState.ConfigurationMissing, AuthUiState.ConfigurationInvalid -> Unit // outer shell supplies these screens
    }
}

@Composable
private fun DriverChooser(state: AuthUiState.Choosing, model: SetupAuthViewModel) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(state.drivers, query) {
        state.drivers.filter { it.displayName.contains(query, ignoreCase = true) }
    }
    val selected = state.drivers.firstOrNull { it.id == state.selectedId }
    BackHandler(state.busy || state.passwordRequested) { model.cancelLogin() }
    Column(Modifier.fillMaxSize().padding(16.dp).testTag("driver_list")) {
        Text(stringResource(R.string.select_driver), style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(
            value = query, onValueChange = { query = it }, enabled = !state.busy,
            label = { Text(stringResource(R.string.search_driver)) }, singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp).testTag("driver_search")
        )
        if (state.invalidCredentials) {
            Text(stringResource(R.string.invalid_credentials), color = MaterialTheme.colorScheme.error,
                modifier = Modifier.testTag("invalid_credentials"))
        }
        if (filtered.isEmpty()) {
            Text(stringResource(if (state.drivers.isEmpty()) R.string.no_active_drivers else R.string.no_driver_matches))
        }
        LazyColumn(Modifier.weight(1f)) {
            items(filtered, key = { it.id }) { driver ->
                Row(
                    Modifier.fillMaxWidth().selectable(
                        selected = state.selectedId == driver.id, enabled = !state.busy,
                        role = Role.RadioButton, onClick = { model.select(driver.id) }
                    ).padding(vertical = 8.dp).testTag("driver_${driver.id}"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = state.selectedId == driver.id, onClick = null)
                    Text(driver.displayName, Modifier.padding(start = 8.dp))
                }
            }
        }
        if (state.busy) {
            CircularProgressIndicator(Modifier.testTag("login_in_progress"))
            TextButton(onClick = model::cancelLogin) { Text(stringResource(R.string.cancel)) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = model::retry, enabled = !state.busy) {
                Text(stringResource(R.string.refresh_drivers))
            }
            Button(onClick = model::requestPassword, enabled = selected != null && !state.busy,
                modifier = Modifier.testTag("login")) { Text(stringResource(R.string.login)) }
        }
    }
    if (state.passwordRequested && selected != null) {
        PasswordDialog(selected.id, selected.displayName, model::cancelLogin, model::login)
    }
}

@Composable
private fun PasswordDialog(driverId: Long, name: String, dismiss: () -> Unit, submit: (CharArray) -> Unit) {
    // Intentionally not rememberSaveable. No ViewModel/SavedStateHandle owns the input String.
    var password by remember(driverId) { mutableStateOf("") }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(driverId, lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) { password = ""; dismiss() }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer); password = "" }
    }
    AlertDialog(
        onDismissRequest = { password = ""; dismiss() },
        title = { Text(stringResource(R.string.driver_password_title, name)) },
        text = {
            OutlinedTextField(
                value = password, onValueChange = { password = it }, singleLine = true,
                label = { Text(stringResource(R.string.password)) },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth().testTag("driver_password")
            )
        },
        confirmButton = {
            TextButton(modifier = Modifier.testTag("confirm_login"), enabled = password.isNotEmpty(), onClick = {
                val input = password.toCharArray()
                password = ""
                submit(input)
            }) { Text(stringResource(R.string.login)) }
        },
        dismissButton = { TextButton(onClick = { password = ""; dismiss() }) { Text(stringResource(R.string.cancel)) } }
    )
}

private fun errorMessage(error: AuthError): Int = when (error) {
    AuthError.CONFIGURATION_MISSING -> R.string.configuration_missing_body
    AuthError.CONFIGURATION_INVALID -> R.string.configuration_invalid
    AuthError.CONNECTION_UNAVAILABLE -> R.string.connection_failed
    AuthError.TLS_REJECTED -> R.string.auth_tls_failed
    AuthError.TIMEOUT -> R.string.auth_timeout
    AuthError.DATABASE_ACCOUNT_REJECTED -> R.string.database_account_rejected
    AuthError.DATA_UNAVAILABLE -> R.string.auth_data_unavailable
    AuthError.LOCAL_STORAGE_UNAVAILABLE -> R.string.auth_storage_unavailable
}
