package ru.ffl24.direct.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import ru.ffl24.direct.domain.*
import ru.ffl24.direct.navigation.*

@Composable
fun DirectoryContent(result: DetailsResult<PhoneDirectory>?, refresh: () -> Unit) {
    val context=LocalContext.current
    if (result !is DetailsResult.Success) { ResultMessage(result,refresh); return }
    val directory=result.value
    LazyColumn(Modifier.fillMaxSize().padding(16.dp).testTag("phone_directory"),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        item {
            Text("Телефонный справочник",style=MaterialTheme.typography.titleLarge)
            TextButton(onClick=refresh) { Text("Обновить") }
            Text("Карта",style=MaterialTheme.typography.titleMedium)
            directory.cardNumber?.let { value ->
                Text(value); TextButton(onClick={ copyDirectory(context,value) }) { Text("Копировать карту") }
            } ?: Text("Номер карты не указан")
            Text(directory.cardHolder ?: "Владелец карты не указан")
            Text("Важные телефоны",style=MaterialTheme.typography.titleMedium)
            if(directory.phones.isEmpty()) Text("Телефонов нет")
        }
        itemsIndexed(directory.phones) { _,phone -> DirectoryRow(phone.name ?: "Телефон",phone.phone) }
        item {
            Text("Активные водители",style=MaterialTheme.typography.titleMedium)
            if(directory.drivers.isEmpty()) Text("Водителей с телефоном нет")
        }
        itemsIndexed(directory.drivers) { _,driver -> DirectoryRow(driver.name,driver.phone) }
    }
}
@Composable
private fun DirectoryRow(name: String, number: String) {
    val context=LocalContext.current
    Column {
        Text(name,style=MaterialTheme.typography.labelLarge);Text(number)
        Row {
            TextButton(onClick={ copyDirectory(context,number) }) { Text("Копировать") }
            if(PhoneActions.dialNumber(number)!=null) TextButton(onClick={
                if(!OrderExternalActions.dial(context,number)) Toast.makeText(context,"Нет приложения для звонков",Toast.LENGTH_SHORT).show()
            }) { Text("Позвонить") }
        }
    }
    HorizontalDivider()
}
private fun copyDirectory(context: Context, value: String) {
    (context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager)?.setPrimaryClip(ClipData.newPlainText("FFL",value))
}
