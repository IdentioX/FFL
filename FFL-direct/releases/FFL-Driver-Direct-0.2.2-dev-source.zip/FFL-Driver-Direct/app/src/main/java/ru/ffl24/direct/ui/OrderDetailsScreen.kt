package ru.ffl24.direct.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ru.ffl24.direct.domain.*
import ru.ffl24.direct.navigation.*
import ru.ffl24.direct.presentation.OrderDetailsUiState
import ru.ffl24.direct.presentation.OrderDetailsViewModel

@Composable
fun OrderDetailsScreen(model: OrderDetailsViewModel, onDeliver: ((OrderId) -> Unit)? = null, deliveryBusy: Boolean = false, deliveryNotice: String? = null) {
    val state by model.state.collectAsStateWithLifecycle()
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(model, lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> model.refresh()
                Lifecycle.Event.ON_STOP -> model.hide()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer); model.hide() }
    }
    val context = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
    OrderDetailsContent(state, model::refresh) { app ->
        model.prepareRoute { contacts ->
            if (!OrderExternalActions.openRoute(context, contacts.routeUrl, app)) {
                Toast.makeText(context, "Не удалось открыть выбранное приложение", Toast.LENGTH_SHORT).show()
            }
        }
    }
        }
        deliveryNotice?.let { Text(it,Modifier.padding(12.dp)) }
        val detail=(state as? OrderDetailsUiState.Content)?.details
        if (onDeliver != null && detail != null && !detail.isDelivered) {
            Button(onClick={ confirm=true },enabled=detail.isReady && !deliveryBusy,modifier=Modifier.fillMaxWidth().padding(12.dp)) { Text("Сдал") }
            if(confirm) DeliveryConfirmation(detail.orderNumber,false,{ confirm=false }) { confirm=false; onDeliver(detail.id) }
        }
    }
}

/** Rendering is independent of JDBC and can be exercised with controlled data. */
@Composable
fun OrderDetailsContent(state: OrderDetailsUiState, onRefresh: () -> Unit, onRoute: (YandexApp) -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp).testTag("order_details"),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        when (state) {
            OrderDetailsUiState.Loading -> { CircularProgressIndicator(); Text("Загрузка заказа…") }
            OrderDetailsUiState.NotFound -> Text("Заказ не найден")
            OrderDetailsUiState.SessionRequired -> Text("Необходимо войти снова")
            OrderDetailsUiState.Disabled -> Text("Недоступно. Доступ водителя отключён")
            is OrderDetailsUiState.Failed -> {
                Text(when (state.error) {
                    AuthError.TLS_REJECTED -> "Безопасное соединение отклонено"
                    AuthError.TIMEOUT -> "Время ожидания истекло"
                    AuthError.CONFIGURATION_MISSING, AuthError.CONFIGURATION_INVALID -> "Подключение не настроено"
                    else -> "Не удалось загрузить заказ"
                })
                TextButton(onClick = onRefresh) { Text("Повторить") }
            }
            is OrderDetailsUiState.Content -> {
                val d = state.details
                Text(d.orderNumber, style = MaterialTheme.typography.titleLarge)
                Text(d.id.source.sectionLabel)
                SelectionContainer { Text(d.title, style = MaterialTheme.typography.titleMedium) }
                SelectionContainer { Text(d.clientName) }
                Text("Адрес", style = MaterialTheme.typography.titleMedium)
                if (d.contacts.addressSource == AddressSource.AMBIGUOUS) {
                    Text("Найдено несколько адресов. Достоверный адрес не выбран.", Modifier.testTag("ambiguous_address"))
                }
                CopyableText(d.contacts.address ?: "Адрес не определён", d.contacts.address)
                Text("Время: ${d.deliveryTime ?: "Не указано"}")
                d.plannedTime?.let { CopyableText("Исходное примечание: $it", it) }
                Text("Комментарий", style = MaterialTheme.typography.titleMedium)
                CopyableText(d.comment ?: "Нет комментария", d.comment)
                ContactParsing.phones(d.rawDeliveryNote).forEach { PhoneRow("Номер из комментария — проверьте перед звонком",it) }
                Text("Накладных: ${d.invoiceCount}")
                Text(d.readinessLabel)
                Text(d.quantityLabel)
                if (d.isDelivered) Text("Сдан${d.deliveredAt?.let { " · $it" }.orEmpty()}")
                PhoneRow("Клиент", d.contacts.clientPhone)
                PhoneRow("Грузчик", d.contacts.loaderPhone)
                d.contacts.managerName?.let { Text("Менеджер: $it") }
                PhoneRow("Менеджер", d.contacts.managerPhone)
                Text("Последние водители", style = MaterialTheme.typography.titleMedium)
                if (d.previousDrivers.isEmpty()) Text("Предыдущих водителей нет")
                d.previousDrivers.take(5).forEach { previous ->
                    HorizontalDivider()
                    Text("${previous.driverName ?: "Водитель"} · ${previous.deliveryDate}")
                    Text(previous.orderNumber)
                    PhoneRow("Телефон", previous.driverPhone)
                    PhoneRow("WhatsApp", previous.driverWhatsapp)
                }
                var chooseRoute by remember(d.id, state.busy) { mutableStateOf(false) }
                val safeUrl = RouteLinks.safeUrl(d.contacts.routeUrl)
                Button(onClick = { chooseRoute = true }, enabled = !state.busy, modifier = Modifier.testTag("route")) {
                    Text(if (safeUrl == null) "Ручной маршрут" else "Маршрут")
                }
                if (chooseRoute) AlertDialog(
                    onDismissRequest = { chooseRoute = false },
                    title = { Text(if (safeUrl == null) "Ручной маршрут" else "Открыть маршрут") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (safeUrl == null) {
                                Text("Уточните адрес перед построением маршрута. Можно скопировать исходный текст заказа и найти адрес вручную.")
                                TextButton(onClick = { copy(context, listOfNotNull(d.rawClientText, d.rawDeliveryNote).joinToString("\n")) }) {
                                    Text("Скопировать исходный текст")
                                }
                            }
                            YandexApp.entries.filter { safeUrl == null || RouteLinks.supports(safeUrl, it) }.forEach { app ->
                                TextButton(onClick = { chooseRoute = false; onRoute(app) }) {
                                    Text(if (app == YandexApp.MAPS) "Яндекс Карты" else "Яндекс Навигатор")
                                }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { chooseRoute = false }) { Text("Отмена") } }
                )
                TextButton(onClick = onRefresh, enabled = !state.busy) { Text("Обновить") }
            }
        }
    }
}

@Composable
private fun PhoneRow(label: String, phone: String?) {
    if (phone == null) return
    val context = LocalContext.current
    Text(label, style = MaterialTheme.typography.labelLarge)
    CopyableText(phone, phone)
    if (PhoneActions.dialNumber(phone) != null) TextButton(onClick = {
        if (!OrderExternalActions.dial(context, phone)) Toast.makeText(context, "Нет приложения для звонков", Toast.LENGTH_SHORT).show()
    }) { Text("Позвонить") }
}

@Composable
private fun CopyableText(display: String, value: String?) {
    val context = LocalContext.current
    SelectionContainer { Text(display) }
    if (value != null) TextButton(onClick = { copy(context, value) }) { Text("Копировать") }
}

private fun copy(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
    clipboard.setPrimaryClip(ClipData.newPlainText("FFL", text))
}
