package ru.ffl24.direct

import android.app.Application
import ru.ffl24.direct.session.DataStoreDriverSessionStore

class DirectApplication : Application() {
    val graph: AppGraph by lazy {
        AppGraph.create(BuildConfig.DATA_SOURCE_MODE, sessionStore = DataStoreDriverSessionStore(this))
    }
}
