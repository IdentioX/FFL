package ru.ffl24.direct.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.coroutines.launch
import ru.ffl24.direct.local.WorkspacePreferences
import ru.ffl24.direct.notifications.SecondRouteNotifications
import ru.ffl24.direct.domain.*
import ru.ffl24.direct.presentation.WorkspaceViewModel
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import ru.ffl24.direct.DirectRuntime
import ru.ffl24.direct.R
import ru.ffl24.direct.presentation.AuthUiState
import ru.ffl24.direct.presentation.SetupAuthViewModel
import ru.ffl24.direct.ui.theme.DirectTheme
import ru.ffl24.direct.domain.OrderId
import ru.ffl24.direct.navigation.OrderDetailsDestination
import ru.ffl24.direct.presentation.OrderDetailsViewModel

private object Routes {
    const val Home = "home"
    const val Settings = "settings"
    const val Directory = "directory"
    const val Second = "second_route"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DirectApp(graph: DirectRuntime, notificationDriver: Long? = null, consumeNotification: () -> Unit = {}) {
    val context = LocalContext.current
    val local = remember { WorkspacePreferences(context) }
    val scope = rememberCoroutineScope()
    var workingDate by rememberSaveable { mutableStateOf(local.date()) }
    var notifications by remember { mutableStateOf(local.notifications()) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        notifications = granted
        scope.launch { saveSetting(context) { local.setNotifications(granted) } }
    }
    val auth: SetupAuthViewModel = viewModel(
        key = "direct-auth-${System.identityHashCode(graph)}", factory = graph.authViewModelFactory
    )
    val authState by auth.state.collectAsStateWithLifecycle()
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(auth, lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> { workingDate=local.date(); auth.onForeground() }
                Lifecycle.Event.ON_STOP -> auth.onBackground()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer); auth.onBackground() }
    }
    var darkTheme by rememberSaveable { mutableStateOf(local.dark()) }
    val session = (authState as? AuthUiState.Authenticated)?.session
    val workspace: WorkspaceViewModel? = if (session == null) null else viewModel(
        key = "workspace-${session.driverId}-$workingDate",
        factory = WorkspaceViewModel.Factory(session.driverId,workingDate,graph.workspaceRepository,local))
    LaunchedEffect(session?.driverId,notifications) {
        if (session != null && notifications) SecondRouteNotifications.schedule(context,session.driverId)
        else if (!notifications || authState is AuthUiState.Choosing || authState == AuthUiState.Disabled) SecondRouteNotifications.cancel(context)
    }
    DirectTheme(darkTheme) {
        val navController = rememberNavController()
        val entry by navController.currentBackStackEntryAsState()
        LaunchedEffect(notificationDriver,session?.driverId) {
            if (notificationDriver != null && session != null) {
                if (notificationDriver == session.driverId) navController.navigate(Routes.Second) { launchSingleTop = true }
                consumeNotification()
            }
        }
        LaunchedEffect(authState) {
            if (authState is AuthUiState.Choosing || authState == AuthUiState.Disabled) navController.popBackStack(Routes.Home,false)
        }
        val onSettings = entry?.destination?.route == Routes.Settings
        val canGoBack = entry?.destination?.route?.let { it != Routes.Home } == true
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                TopAppBar(
                    title = {
                        val session = (authState as? AuthUiState.Authenticated)?.session
                        Text(if (onSettings) stringResource(R.string.settings)
                            else session?.displayName ?: stringResource(R.string.app_name))
                    },
                    navigationIcon = {
                        if (canGoBack) {
                            TextButton(onClick = { navController.popBackStack() }, modifier = Modifier.testTag("back")) {
                                Text(stringResource(R.string.back))
                            }
                        }
                    },
                    actions = {
                        if (session != null && !onSettings) {
                            TextButton(onClick = { navController.navigate(Routes.Directory) { launchSingleTop = true } }) { Text("Телефоны") }
                        }
                        if (!onSettings) {
                            TextButton(
                                onClick = { navController.navigate(Routes.Settings) { launchSingleTop = true } },
                                modifier = Modifier.testTag("open_settings")
                            ) { Text(stringResource(R.string.settings)) }
                        }
                    }
                )
            }
        ) { padding ->
            NavHost(navController, startDestination = Routes.Home, modifier = Modifier.padding(padding)) {
                composable(Routes.Home) {
                    when (authState) {
                        AuthUiState.ConfigurationMissing -> ConfigurationMissingScreen()
                        AuthUiState.ConfigurationInvalid -> ConnectionMessage(R.string.configuration_invalid, "configuration_invalid")
                        is AuthUiState.Authenticated -> key(session!!.driverId,workingDate) {
                            DriverOrdersScreen(workspace!!, { OrderDetailsDestination.open(navController,it) }, auth::recheckAccess)
                        }
                        else -> AuthScreen(authState, auth)
                    }
                }
                composable(Routes.Settings) {
                    WorkspaceSettings(darkTheme, { darkTheme = it; scope.launch { saveSetting(context) { local.setDark(it) } } },
                        workingDate, { date -> scope.launch { saveSetting(context) { local.setDate(date); workingDate=local.date() } } },
                        notifications, { enabled ->
                            if (enabled && android.os.Build.VERSION.SDK_INT >= 33 && !SecondRouteNotifications.allowed(context))
                                permission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                            else { notifications=enabled; scope.launch { saveSetting(context) { local.setNotifications(enabled) } } }
                        }, { scope.launch { SecondRouteNotifications.cancel(context); auth.logout(); saveSetting(context) { local.clearSeen() } } }, session != null)
                }
                composable(Routes.Second) {
                    if (session != null) {
                        // A separate navigation entry must not cancel the home entry's read during transitions.
                        val secondModel: WorkspaceViewModel = viewModel(
                            key="second-${session.driverId}-$workingDate",
                            factory=WorkspaceViewModel.Factory(session.driverId,workingDate,graph.workspaceRepository,local))
                        DriverOrdersScreen(secondModel,{ OrderDetailsDestination.open(navController,it) },auth::recheckAccess,second=true)
                    } else AuthScreen(authState,auth)
                }
                composable(Routes.Directory) {
                    if (session == null) AuthScreen(authState,auth) else key(session.driverId) {
                        var result by remember { mutableStateOf<DetailsResult<PhoneDirectory>?>(null) }
                        var revision by remember { mutableStateOf(0) }
                        LaunchedEffect(revision) {
                            result=null; result=graph.workspaceRepository.directory()
                            if (result == DetailsResult.DriverDisabled || result == DetailsResult.SessionRequired) auth.recheckAccess()
                        }
                        DirectoryContent(result) { revision++ }
                    }
                }

                composable(OrderDetailsDestination.pattern) { detailsEntry ->
                    val id = OrderId.parse(detailsEntry.arguments?.getString("orderId").orEmpty())
                    val session = (authState as? AuthUiState.Authenticated)?.session
                    if (session == null) {
                        AuthScreen(authState, auth)
                    } else if (id == null) {
                        Text("Заказ не найден", Modifier.padding(24.dp))
                    } else {
                        key(session.driverId, id.wire) {
                            val model: OrderDetailsViewModel = viewModel(
                                key = "details-${session.driverId}-${id.wire}",
                                factory = OrderDetailsViewModel.Factory(id, graph.orderDetailsRepository)
                            )
                            val busy by workspace!!.busy.collectAsStateWithLifecycle()
                            val notice by workspace.notice.collectAsStateWithLifecycle()
                            OrderDetailsScreen(model, { workspace.deliver(it) { model.refresh() } }, busy, notice)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ConnectionMessage(message: Int, tag: String) {
    Column(Modifier.fillMaxSize().padding(24.dp).testTag(tag), verticalArrangement = Arrangement.Center) {
        Text(stringResource(message))
    }
}

@Composable
private fun ConfigurationMissingScreen() {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp).testTag("configuration_missing"),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(stringResource(R.string.configuration_missing_title), style = MaterialTheme.typography.titleLarge)
        Text(
            stringResource(R.string.configuration_missing_body),
            modifier = Modifier.padding(top = 16.dp),
            style = MaterialTheme.typography.bodyLarge
        )
    }
}

private suspend fun saveSetting(context: android.content.Context, save: suspend () -> Unit) {
    try { save() } catch (e: kotlinx.coroutines.CancellationException) { throw e }
    catch (_: Exception) { android.widget.Toast.makeText(context,"Не удалось сохранить настройку",android.widget.Toast.LENGTH_SHORT).show() }
}
