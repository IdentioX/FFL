# FFL Driver Direct 0.2.1-dev

Независимое Android-приложение `ru.ffl24.direct.dev`: Compose→JDBC/TLS→MySQL/MariaDB, без FastAPI/JWT/API fallback и экрана backend IP. Старые FFL/FFL-backend сохранены без изменений.

Реализованы вход/access gate/local session, первый и второй рейс/сданные, source-aware IDs, детали/адреса/контакты/5водителей, сортировка и scroll, транзакционная «Сдал», справочник, тема/дата, opt-in уведомления второго рейса. Дата по умолчанию сегодня; для тестов используется явно выбранная дата. Polling WorkManager>=15мин, без обещания точного времени в Doze.

## Восстановленная тестовая БД

Предоставленный полный SQL собран из5ZIP-частей, все SHA проверены. Поднята отдельная MariaDB10.6.25 с101таблицей и исходными данными; production не используется. Настоящие MainActivity/DirectApplication/BuildConfig работают с этой копией. После импорта локализованы DEFINER routines/triggers с проверкой неизменности их кода. Server triggers не отключаются; rollback проверяется вместе с связанной BF записью.

[Восстановление, запуск и Windows](docs/direct-rewrite/RESTORED_DATABASE.md), [общая локальная среда](docs/direct-rewrite/LOCAL_DATABASE.md), [результаты и evidence](docs/direct-rewrite/PROGRESS.md).

В подготовленной Linux-среде:

```bash
source /workspace/.ffl/env.sh
export FFL_DEV_STATE_DIR=/workspace/.ffl/direct-restored
python3 tools/dev_database.py start
python3 tools/dev_database.py status
python3 tools/dev_database.py prepare-restored
python3 tools/dev_database.py build
# На запущенном выделенном тестовом эмуляторе:
python3 tools/dev_database.py test-restored --serial emulator-5558
```

Если Docker-ресурсы не сохранились, `up --dump /private/path/112.sql.gz --port 19066` восстанавливает собственную копию заново. Не переключайте/не удаляйте существующий профиль автоматически. Source ZIP не содержит личную БД: используйте собственные предоставленные архивы и kit00. На Windows Python3.11+/Docker Desktop/OpenSSL/JDK21/Android SDK, свои пути/serial; Linux env.sh на Windows не используется. Команды Windows подготовлены, но не запускались на Windows.

Тестовые записи: поиск `FFL E2E`, fictional password `ffl-e2e-only-42`, дата2099-12-31. Они изолированы высоким диапазоном ID и marker; исходные строки сверяются с независимым чистым импортом. Raw персональные данные/реальные пароли/настроенный APK/private logs находятся вне checkout, не включаются в публичные артефакты.

## Сборка без конфигурации

JDK21, Android SDK36.1/build-tools36.0.0, Gradle wrapper. Compose BOM2026.03.01 (runtime/ui/foundation1.10.6), Kotlin2.2.10, pinned MariaDB Connector/J3.5.10.

```bash
bash gradlew --no-daemon --max-workers=2 :app:assembleDebug :app:testDebugUnitTest :app:lintDebug :app:verifyDirectRuntime :app:assembleDebugAndroidTest :app:assembleRelease
```

[Credentials-free APK](releases/FFL-Driver-Direct-0.2.1-dev.apk) устанавливается отдельно от старого приложения. Без DB BuildConfig он показывает «Подключение не настроено». Настроенная рабочая тестовая сборка создаётся `dev_database.py build/android`; её generated sources/cache/APK вынесены в private state, реквизиты через environment, без значений в argv. Она содержит извлекаемый одноразовый локальный пароль, не публикуйте её. Root и production credentials в APK не используются.

Release R8 собирается unsigned, для установки не выдаётся. Debug подписан Android debug key. Точные hash и installed APK proof — PROGRESS/evidence. [Ручная конфигурация](docs/direct-rewrite/MYSQL_CONNECTION_LAYER.md) содержит исторические ограничения P2; текущие business functions и проверки — RESTORED_DATABASE/PROGRESS.

## Проверки и ограничения

Шесть Android методов на восстановленном schema/data: read-only original-record SQL/DTO/order/summary parity, ordinary UI/login/date/both tables/delivery/directory, cold-process session/date restore/logout, controlled actual-schema auth/access/owner/resolver/history/rollback/idempotency, paired server-trigger rollback/repeat, actual WorkManager SQL→notification→PendingIntent second route/dedup. Отдельные8Compose fixture tests покрывают sort/scroll/pull/confirmation/copy/channel. Они не подменяют друг друга. JVM/build/lint и финальные counts — PROGRESS. При crash/missing XML/skip успех не объявляется.

Оригинальные359,540строк во всех101таблицах проверяются `tools/check_restored_integrity.py`; этот read-only checker требует PyMySQL из tools/requirements-db-check.txt и публикует только hashes/counts. Базовый Docker/Android helper работает без PyMySQL.

Physical device, Windows runtime, minified runtime, реальные Яндекс/звонки и measured15мин/Doze/reboot не проверены. Общий DB account не обеспечивает server row isolation; функциональный test PASS не разрешает driver rollout. [SECURITY_RISKS](docs/direct-rewrite/SECURITY_RISKS.md), [UI comparison](docs/direct-rewrite/UI_PARITY.md). DRIVER_ROLLOUT=BLOCKED_SECURITY. Исторические verify_p2/verify_p5/verify_completion относятся к прежним этапам; не запускайте их как итоговый валидатор восстановленной БД.
