package ru.ffl24.direct.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.FlowPreview
import ru.ffl24.direct.domain.*
import ru.ffl24.direct.presentation.WorkspaceViewModel

@Composable
fun DriverOrdersScreen(model: WorkspaceViewModel, onDetails: (OrderId) -> Unit, onAccess: () -> Unit, second: Boolean = false) {
    val state by model.state.collectAsStateWithLifecycle()
    val busy by model.busy.collectAsStateWithLifecycle()
    val notice by model.notice.collectAsStateWithLifecycle()
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(model,lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_START) model.refresh()
            if (event == Lifecycle.Event.ON_STOP) model.hide()
        }
        lifecycle.addObserver(observer); model.refresh()
        onDispose { lifecycle.removeObserver(observer); model.hide() }
    }
    LaunchedEffect(state) { if (state == DetailsResult.DriverDisabled || state == DetailsResult.SessionRequired) onAccess() }
    OrdersContent(state, model.date, busy, notice, model::refresh, model::resetOrder, model::move, onDetails, { model.deliver(it) }, second,model.scrollPositions,model::saveScroll)
}

@OptIn(FlowPreview::class, ExperimentalMaterial3Api::class)
@Composable
fun OrdersContent(state: DetailsResult<List<DriverOrder>>?, date: String, busy: Boolean, notice: String?,
    refresh: () -> Unit, reset: () -> Unit, move: (OrderSection,OrderId,Int) -> Unit,
    details: (OrderId) -> Unit, deliver: (OrderId) -> Unit, second: Boolean = false, positions: Map<Int,Pair<Int,Int>> = emptyMap(), saveScroll: (Int,Int,Int)->Unit = {_,_,_->}) {
    var sectionIndex by rememberSaveable { mutableIntStateOf(if (second) 1 else 0) }
    val firstScroll = rememberLazyListState(positions[0]?.first ?: 0,positions[0]?.second ?: 0)
    val secondScroll = rememberLazyListState(positions[1]?.first ?: 0,positions[1]?.second ?: 0)
    val deliveredScroll = rememberLazyListState(positions[2]?.first ?: 0,positions[2]?.second ?: 0)
    val scroll = listOf(firstScroll,secondScroll,deliveredScroll)[sectionIndex]
    LaunchedEffect(scroll,sectionIndex) {
        snapshotFlow { scroll.firstVisibleItemIndex to scroll.firstVisibleItemScrollOffset }.distinctUntilChanged().debounce(250).collect { saveScroll(sectionIndex,it.first,it.second) }
    }
    DisposableEffect(scroll,sectionIndex) { onDispose { saveScroll(sectionIndex,scroll.firstVisibleItemIndex,scroll.firstVisibleItemScrollOffset) } }
    var confirmation by remember { mutableStateOf<DriverOrder?>(null) }
    val rows = (state as? DetailsResult.Success)?.value.orEmpty()
    PullToRefreshBox(isRefreshing=state==null,onRefresh=refresh,modifier=Modifier.fillMaxSize().testTag("orders_refresh")) {
    Column(Modifier.fillMaxSize().testTag("orders")) {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            Text(date,Modifier.padding(12.dp))
            TextButton(onClick=refresh,enabled=!busy) { Text("Обновить") }
            TextButton(onClick=reset,enabled=!busy) { Text("Сбросить порядок") }
        }
        Row(Modifier.fillMaxWidth()) { OrderSection.entries.forEachIndexed { i,section ->
            TextButton(onClick={ sectionIndex=i },modifier=Modifier.weight(1f).testTag("section_$i")) {
                Text("${if (i == sectionIndex) "● " else ""}${section.label}\n${rows.count { it.section == section }}")
            }
        } }
        notice?.let { Text(it,Modifier.padding(12.dp).testTag("delivery_notice")) }
        when (state) {
            null -> CircularProgressIndicator(Modifier.padding(24.dp))
            is DetailsResult.Success -> {
                val section = OrderSection.entries[sectionIndex]
                val selected = rows.filter { it.section == section }
                if (selected.isEmpty()) Text("Заказов нет",Modifier.padding(24.dp))
                val threshold = with(LocalDensity.current) { 64.dp.toPx() }
                LazyColumn(state=scroll,modifier=Modifier.weight(1f).testTag("order_list")) {
                    items(selected,key={ it.id.wire }) { row ->
                        var drag by remember(row.id) { mutableFloatStateOf(0f) }
                        Column(Modifier.fillMaxWidth().clickable { details(row.id) }
                            .pointerInput(row.id,section) {
                                detectDragGesturesAfterLongPress(onDragStart={ drag=0f },onDragEnd={ drag=0f },onDragCancel={ drag=0f }) { change, amount ->
                                    change.consume(); drag += amount.y
                                    if (kotlin.math.abs(drag) > threshold) { move(section,row.id,if (drag > 0) 1 else -1); drag=0f }
                                }
                            }.padding(horizontal=12.dp,vertical=8.dp).testTag("order_${row.id.wire}")) {
                            Text("${row.orderNumber} · ${row.readinessLabel} · Накладных: ${row.invoiceCount}",style=MaterialTheme.typography.labelLarge)
                            Text(row.clientName,maxLines=2,style=MaterialTheme.typography.bodyLarge)
                            row.contacts.address?.let { Text(it,maxLines=2) }
                            row.note?.let { Text(it,maxLines=1,style=MaterialTheme.typography.bodySmall) }
                            Text(when(row.quantityReadiness) {0L->"Накладные не готовы";1L->"Частично готово";2L->"Все накладные готовы";else->"Готовность накладных неизвестна"},style=MaterialTheme.typography.bodySmall)
                            if (row.isDelivered) Text("Сдан · ${row.deliveredAt ?: "Время не указано"}")
                            Row {
                                TextButton(onClick={ move(section,row.id,-1) }) { Text("↑") }
                                TextButton(onClick={ move(section,row.id,1) }) { Text("↓") }
                                TextButton(onClick={ details(row.id) }) { Text("Детали / Маршрут") }
                                if (!row.isDelivered) TextButton(onClick={ confirmation=row },enabled=row.isReady && !busy) { Text("Сдал") }
                            }
                        }
                        HorizontalDivider()
                    }
                }
            }
            else -> ResultMessage(state) { refresh() }
        }
    }
    }
    confirmation?.let { row -> DeliveryConfirmation(row.orderNumber,true,{ confirmation=null }) {
        confirmation=null; deliver(row.id)
    } }
}

@Composable
fun DeliveryConfirmation(number: String, countdown: Boolean, dismiss: () -> Unit, confirm: () -> Unit) {
    var seconds by remember { mutableIntStateOf(if (countdown) 5 else 0) }
    LaunchedEffect(Unit) { while (seconds > 0) { delay(1000); seconds-- } }
    AlertDialog(onDismissRequest=dismiss,title={ Text("Сдать заказ $number?") },
        text={ Text("Подтвердите, что заказ доставлен. Действие сохранится в базе.") },
        confirmButton={ TextButton(onClick=confirm,enabled=seconds==0,modifier=Modifier.testTag("confirm_delivery")) { Text(if(seconds>0) "Подтвердить ($seconds)" else "Подтвердить") } },
        dismissButton={ TextButton(onClick=dismiss) { Text("Отмена") } })
}

@Composable
fun ResultMessage(result: DetailsResult<*>?, retry: () -> Unit) {
    Column(Modifier.padding(24.dp)) {
        Text(when(result) {
            DetailsResult.DriverDisabled -> "Недоступно. Доступ водителя отключён"
            DetailsResult.SessionRequired -> "Необходимо войти снова"
            DetailsResult.NotFound -> "Данные не найдены"
            is DetailsResult.Failed -> when(result.error) {
                AuthError.TIMEOUT -> "Время ожидания истекло"
                AuthError.TLS_REJECTED -> "Безопасное соединение отклонено"
                AuthError.CONNECTION_UNAVAILABLE -> "Нет соединения"
                else -> "Не удалось загрузить данные"
            }
            else -> "Загрузка…"
        })
        TextButton(onClick=retry) { Text("Повторить") }
    }
}
