package ru.ffl24.direct.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

// Палитра и типографика взяты из reference; Activity/window cast не переносится.
private val lightColors = lightColorScheme(
    primary = AppPrimary,
    onPrimary = AppOnPrimary,
    background = AppBackground,
    onBackground = AppText,
    surface = AppSurface,
    onSurface = AppText,
    primaryContainer = AppPrimaryDark,
    onPrimaryContainer = AppOnPrimary
)
private val darkColors = darkColorScheme(
    primary = AppPrimary,
    onPrimary = AppOnPrimary,
    background = AppDarkBackground,
    onBackground = AppDarkText,
    surface = AppDarkSurface,
    onSurface = AppDarkText,
    primaryContainer = AppPrimaryDark,
    onPrimaryContainer = AppOnPrimary
)

@Composable
fun DirectTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) darkColors else lightColors,
        typography = Typography,
        content = content
    )
}
