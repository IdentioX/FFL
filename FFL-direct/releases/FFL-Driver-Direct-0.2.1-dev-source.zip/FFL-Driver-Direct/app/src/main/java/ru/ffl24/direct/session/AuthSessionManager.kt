package ru.ffl24.direct.session

import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import ru.ffl24.direct.domain.DriverSession

internal data class SessionSnapshot(val revision: Long, val session: DriverSession?)

/** Serialize disk publication and invalidate obsolete login/restore after logout/new attempts. */
class AuthSessionManager(private val store: DriverSessionStore) {
    private var revision = 0L
    private val disk = Mutex()
    private var active: DriverSession? = null

    @Synchronized internal fun invalidate(): Long {
        val next = ++revision
        active = null
        return next
    }

    internal suspend fun saved(): SessionSnapshot {
        val token = invalidate() // stored identity never leaves an old in-memory grant active while restoring
        return disk.withLock { SessionSnapshot(token, store.read()) }
    }

    @Synchronized internal fun current() = SessionSnapshot(revision, active)

    @Synchronized internal fun invalidateIfCurrent(expected: Long): Long? =
        if (revision == expected) invalidate() else null

    internal suspend fun clear(expected: Long) = disk.withLock {
        if (current().revision == expected) {
            synchronized(this) { if (revision == expected) active = null }
            store.clear()
        }
    }

    internal suspend fun publish(session: DriverSession, expected: Long, persist: Boolean): Boolean = disk.withLock {
        if (current().revision != expected) return@withLock false
        try {
            if (persist) store.save(session)
            currentCoroutineContext().ensureActive()
            val accepted = synchronized(this) {
                if (revision == expected) { active = session; true } else false
            }
            if (!accepted) {
                if (persist) store.clear()
                false
            } else {
                true
            }
        } catch (failure: CancellationException) {
            synchronized(this) { if (revision == expected) active = null }
            // An atomic DataStore edit may have committed before cancellation was delivered.
            if (persist) withContext(NonCancellable) {
                try { store.clear() } catch (_: IOException) {
                    failure.addSuppressed(IOException("Session cleanup failed"))
                }
            }
            throw failure
        }
    }
}
