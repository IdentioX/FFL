# FFL Driver Direct 0.2.0-dev

Отдельное Android-приложение `ru.ffl24.direct.dev`: Compose + DIRECT_MYSQL, без API, JWT и экрана backend IP. Старые FFL/FFL-backend не изменяются.

Реализованы вход активного водителя и access gate, три раздела заказов из reys/reys_den, детали/адреса/контакты/история, локальная сортировка и прокрутка, транзакционная кнопка «Сдал», телефонный справочник, opt-in уведомления второго рейса, тема и рабочая дата. Дата по умолчанию — сегодня, её можно явно изменить в настройках. Уведомления через WorkManager не чаще одного запроса в15мин; первый запрос задаёт baseline.

[APK](releases/FFL-Driver-Direct-0.2.0-dev.apk) — подписанная debug-сборка для установки отдельно от старого приложения. Она **без DB credentials**: стартует с «Подключение не настроено», реквизиты в водительском UI не вводятся. Для работы с вашей БД нужна сборка с `DIRECT_MYSQL_*` и доверенной CA: [настройка](docs/direct-rewrite/MYSQL_CONNECTION_LAYER.md). Пароли не добавлять в Git/чат/аргументы команд. BuildConfig с заполненными реквизитами извлекается из APK; это developer-кандидат, не разрешение на массовое распространение.

## Сборка

JDK21, Android SDK36.1/build-tools36.0.0; Gradle wrapper закреплён. В этой среде toolchain: `/workspace/.ffl/env.sh`. В другом окружении настройте собственные JAVA_HOME/ANDROID_HOME и ignored local.properties.

```bash
bash gradlew --no-daemon --max-workers=2 :app:assembleDebug :app:testDebugUnitTest :app:lintDebug :app:verifyDirectRuntime :app:assembleDebugAndroidTest :app:assembleRelease
```

Debug: `app/build/outputs/apk/debug/app-debug.apk`. Release minified собирается без подписи; ключ релиза в проект не включён. `tools/verify_completion.py` проверяет локальные артефакты и сохранность reference-проектов в этой среде; он не заменяет Android/DB тесты.

## Проверки

Актуальные команды, результаты, хеши и отдельные emulator/physical-device/legacy-DB статусы — [PROGRESS](docs/direct-rewrite/PROGRESS.md). Реальный Android→JDBC→TLS→MySQL путь проверен на собственном одноразовом синтетическом MySQL8.4.11 стенде. Его configuration находится только в androidTest; в main APK нет ни этого стенда, ни тестового логина, ни fake runtime. Обычный `connectedDebugAndroidTest` без отдельной настройки fixture пропустит два MySQL integration tests; это не PASS.

Поведение и ограничения: [COMPLETION](docs/direct-rewrite/COMPLETION.md), [сравнение экранов](docs/direct-rewrite/UI_PARITY.md), [модель угроз](docs/direct-rewrite/SECURITY_RISKS.md). Физический телефон, ваша legacy БД, реальные Яндекс-приложения и длительное фоновое поведение пока не проверены. DRIVER_ROLLOUT=BLOCKED_SECURITY до серверного разграничения доступа.

Происхождение: wrapper/checksum/toolchain из FFL, theme Color/Type с новым package и launcher resources из reference; runtime написан отдельно. История этапов сохранена в документации. Последнее указание пользователя отменило prerequisite POSITIVE/STOP; исторические BLOCKED не препятствуют разработке и не превращены в вымышленные успешные проверки.
